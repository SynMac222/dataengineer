# Databricks notebook source
# MAGIC %python
# MAGIC course_name = "Core Partner Enablement"
