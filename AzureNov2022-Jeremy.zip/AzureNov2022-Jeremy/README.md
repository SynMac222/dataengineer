# AzureNov2022
Training materials and exercises for python and databricks
